package com.example;

public class CouchbaseRuntimeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
