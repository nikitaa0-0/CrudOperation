package com.example;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.ClusterOptions;
import com.couchbase.client.java.Collection;
import com.couchbase.client.java.json.JsonObject;

public class CouchbaseCrudApp {

    public static void main(String[] args) {
        Cluster cluster = Cluster.connect("couchbase://localhost", ClusterOptions.clusterOptions("admin", "Couchbase@04"));
        Bucket bucket = cluster.bucket("my_bucket");
        Collection collection = bucket.defaultCollection();

        try {
            // Create
            JsonObject document = ((JsonObject) JsonObject.create()).put("field1", "value1").put("field2", "value2");
            collection.upsert("document-key", document);
            System.out.println("Document created.");

            // Read
            JsonObject retrievedDocument = ((JsonObject) collection.get("document-key")).contentAsObject();
            System.out.println("Retrieved document: " + retrievedDocument);

            // Update
            JsonObject updatedDocument = retrievedDocument.put("field2", "new-value");
            collection.replace("document-key", updatedDocument);
            System.out.println("Document updated.");

            // Delete
            collection.remove("document-key");
            System.out.println("Document deleted.");
        } finally {
            cluster.disconnect();
        }
    }
}

