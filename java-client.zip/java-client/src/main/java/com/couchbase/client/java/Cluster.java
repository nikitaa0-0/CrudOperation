package com.couchbase.client.java;

public class Cluster {

	public static Cluster connect(String string, Object clusterOptions) {
		// TODO Auto-generated method stub
		return null;
	}

	public Bucket bucket(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void disconnect() {
		// TODO Auto-generated method stub
		
	}

}
