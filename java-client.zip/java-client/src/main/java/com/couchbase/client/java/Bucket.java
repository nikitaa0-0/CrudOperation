package com.couchbase.client.java;

public class Bucket {

	public Collection defaultCollection() {
		// TODO Auto-generated method stub
		return null;
	}

}
