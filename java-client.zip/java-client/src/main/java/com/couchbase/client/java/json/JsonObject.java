package com.couchbase.client.java.json;

public class JsonObject {

	public static Object create() {
		// TODO Auto-generated method stub
		return null;
	}

	public JsonObject put(String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}

	public JsonObject contentAsObject() {
		// TODO Auto-generated method stub
		return null;
	}

}
