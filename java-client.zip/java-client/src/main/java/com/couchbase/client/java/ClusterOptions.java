package com.couchbase.client.java;

public class ClusterOptions {

	public static Object clusterOptions(String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}

}
