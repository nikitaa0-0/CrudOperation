package com.couchbase.client.core.error;

public class CouchbaseException {

	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
