package com.couchbase.client.java;

import com.couchbase.client.java.json.JsonObject;

public class Collection {

	public void upsert(String string, JsonObject document) {
		// TODO Auto-generated method stub
		
	}

	public Object get(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void replace(String string, JsonObject updatedDocument) {
		// TODO Auto-generated method stub
		
	}

	public void remove(String string) {
		// TODO Auto-generated method stub
		
	}

}
